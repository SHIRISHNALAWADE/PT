const express = require("express");
const myrouter = express.Router();

var connection = require("../db/db");

myrouter.get("/",(req,resp) => {
    connection.query("select * from pt",(err,data,field) => {
        if(err){
            console.log("error occured",err);
        }
        else{
            resp.render("index",{data:data});
            console.log("connection get the data");
        }
    });
});

myrouter.post("/", (req, resp) => {
    const { name, email, contact } = req.body;
    connection.query("insert into pt (name,email,contact) value(?,?,?)", [name, email, contact], (err, result) => {
        if (err) {
            console.log("err occured in  inserting");
        } else {
            resp.redirect('/');
        }
    });
});

myrouter.post("/delete/:id",(req,resp) => {
    const delid = req.params.id;

    connection.query("delete from pt where id=?",[delid],(err,result) => {
        if(err){
            console.log("error deleting ");
            resp.status(500).send("error deleting");
        }
        else{
            console.log("deleted");
            resp.redirect("/");
        }
    });
});

myrouter.post("/update/:id",function(req,resp){
    const itemId=req.params.id;
    const{updatedName,updatedEmail,updatedContact}=req.body;

    connection.query("update pt set name=?,email=?,contact=? where id=?",[updatedName,updatedEmail,updatedContact,itemId],(err,result)=>{
        if(err){
            console.log("error occured while updating ");
            resp.status(500).send("error occured while updating data ");
        }else{
            console.log("Data updated succesfully");
            resp.redirect('/');
        }
    });
});



module.exports = myrouter;