const mysql=require("mysql");

var connection =mysql.createConnection({
    host:"localhost", //127.0.0.1
    database:"wptem",
    user:"root",
    password:"root123",
    port:3306
});

connection.connect((err)=>{
    if(!err){
        console.log("CONNECTED TO DB");
    }
    else{
        console.log("ERROR");
    }
});

module.exports=connection;