const express = require("express");
const bodyparser = require("body-parser");
const cors = require("cors");
const path = require('path');
const routes = require("./routes/router");

const app = express();

app.use(cors());
app.use(bodyparser.urlencoded({extended:false}));
app.use(bodyparser.json());
app.use("/",routes);

app.set('view engine','ejs');
app.set('views',path.join(__dirname,'views'));

app.get("/",(req,resp) =>{
    resp.render('index',{ data:[]});
});

app.listen(9000,()=>{
    console.log("started on port 9000");   
});

module.exports=app;