const express=require('express')
const myrouter=express.Router()
const connection=require('../db/mysqlconnection')


myrouter.get("/show",(req,res)=>
{
     connection.query("select * from student",(err,data,fields)=>
     {
          if(err)
          {
            res.status(500).send("not found")
          }
          else{
            console.log(data)
            res.render("index",{studarr:data})
          }
     })
 })

myrouter.get("/delete/:rollno",(req,res)=>
{
   connection.query("delete from student where rollno=?",[req.params.rollno],(err,result)=>
   {
         if(!err)
         {
           res.redirect("/show")
         }
         else{
          console.log(err)
         }
        })

  })


myrouter.get("/update/:rollno",(req,res)=>
{
  connection.query("select * from student where rollno=?",[req.params.rollno],(err,data,fields)=>
  {
       if(err)
       {
         res.status(500).send("not found")
       }
       else{
         console.log(data)
         res.render("update",{studarr:data})
       }
  })
})

myrouter.get("/update",(req,res)=>
{
  console.log(req)
  connection.query("update student set name=?,age=?,division=? where rollno=?",[req.query.name,req.query.age,req.query.division,req.query.rollno],(err,result)=>
  {
    if(!err)
    {
      res.redirect("/show")
    }
    else{
      console.log(err)
    }
  })
})


myrouter.get("/add",(req,res)=>
{
      res.render("add")
  }


)


myrouter.get("/addstu",(req,res)=>
{
   connection.query("insert into student values(?,?,?,?)",[req.query.rollno,req.query.name,req.query.age,req.query.division],(err,result)=>
   {
       if(!err)
       {
        res.redirect("/sho")
       }
   })
})


myrouter.get("/showstu",(req,res)=>
{
     connection.query("select * from student",(err,data,fields)=>
     {
          if(err)
          {
            res.status(500).send("not found")
          }
          else{
            console.log(data)
            res.send(data)
          }
     })
 })
module.exports=myrouter;