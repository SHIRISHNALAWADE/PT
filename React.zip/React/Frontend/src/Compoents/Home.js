export default function HomeComponent()
{
    return (
        <h1>Hello this the second React app for Pracitce</h1>
    )
}

