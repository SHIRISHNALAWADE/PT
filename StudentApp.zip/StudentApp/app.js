
const express = require('express');
const path = require('path');
const bodyparser = require('body-parser');
const routes=require('./Routes/route');

const app=express();

app.set('views',path.join(__dirname,'views'));
app.set('view engine','ejs');

app.use(bodyparser.urlencoded({extends:false}));

app.use('/',routes);

app.listen(9000,()=>{
    console.log("Portal listning on 9000");
});
module.exports=app;