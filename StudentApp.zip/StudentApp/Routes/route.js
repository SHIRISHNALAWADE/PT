const express = require("express");
const myroute = express.Router();
const connection = require("../DB/dbconnect");

myroute.get("/students",(req,resp)=>{
    connection.query("select * from students",(err,data)=>{
        if(err){
            console.log("No data found");
        }else{
            resp.render("index",{arr:data});
        }
    })
});
myroute.get("/add",(req,resp)=>{
    resp.render("student-form");
});
myroute.get("/details/:id",(req,resp)=>{
    connection.query("select * from students where id=?",[req.params.id],(err,data)=>{
        if(err){
            console.log("No data found");
        }else{
            resp.render('details',{arr:data});
        }
    })
});
myroute.post("/insert",(req,resp)=>{
    connection.query("insert into students values(?,?,?,?,?,?,?)",[req.body.id,req.body.name,req.body.course,req.body.email,req.body.password,
    req.body.city,req.body.age],(err,result)=>{
        if(err){
            console.log("Data not inserted",err);
        }else{
            resp.redirect("/students");
        }
    })
})
myroute.get("/delete/:id",(req,resp)=>{
    connection.query("delete from students where id=?",[req.params.id],(err,result)=>{
        if(err){
            console.log("Data not deleted",err);
        }else{
            resp.redirect("/students");
        }
    });
});
myroute.get("/update/:id",(req,resp)=>{
    connection.query("select * from students where id=?",[req.params.id],(err,data)=>{
        if(err){
            console.log("Data not fetch",err);
        }else{
            resp.render('update',{arr:data});
        }
    })
});
myroute.post("/update",(req,resp)=>{
    connection.query("update students set name=?,course=?,email=?,password=?,city=?,age=? where id=?",[req.body.name,
    req.body.course,req.body.email,req.body.password,req.body.city,req.body.age,req.body.id],(err,result)=>{
        if(err){
            console.log("data not update",err);
        }else{
            resp.redirect("/students");
        }
    })
})

module.exports=myroute;