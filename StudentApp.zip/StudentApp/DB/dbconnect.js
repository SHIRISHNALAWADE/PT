const sql = require('mysql');

const mysql=sql.createConnection({
    host:'localhost',
    user:'root',
    password:'root123',
    database:'student',
    port:3306
});
mysql.connect((err)=>{
if(err){
    console.log("DB not connected ",err);
}
else{
    console.log("Db connected");
}
});
module.exports=mysql;

